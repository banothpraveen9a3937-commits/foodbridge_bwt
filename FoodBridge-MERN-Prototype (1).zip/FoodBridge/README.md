# FoodBridge — MERN Food Donation Marketplace

A hackathon-ready starter prototype with:
- React + Vite frontend
- Node.js + Express REST API
- MongoDB + Mongoose persistence
- Registration/login with hashed passwords and JWT
- Donor and NGO roles
- Donation statuses: Available → Reserved → Collected
- Search and filters
- Responsive, gradient-based UI

## Requirements
- Node.js LTS
- MongoDB Atlas account or a local MongoDB server

## 1. Configure MongoDB
Create a MongoDB database/user and allow your current IP in Atlas Network Access.
Copy the Node.js connection string. Put it in `backend/.env` as `MONGO_URI`.
Never publish `.env` or your real database password.

## 2. Install dependencies
From the root `FoodBridge` folder:
```bash
npm install
npm run install:all
```

## 3. Configure backend
Copy `backend/.env.example` to `backend/.env`, then set:
```env
MONGO_URI=mongodb+srv://YOUR_USER:YOUR_PASSWORD@YOUR_CLUSTER.mongodb.net/foodbridge
JWT_SECRET=replace_this_with_a_long_random_secret
PORT=5000
CLIENT_ORIGIN=http://localhost:5173
```
Use a long random JWT secret. If your MongoDB password contains special characters, URL-encode them.

## 4. Run both apps
From the root folder:
```bash
npm run dev
```
Frontend: http://localhost:5173
Backend health check: http://localhost:5000/api/health

You can also run them separately:
- `npm run dev --prefix backend`
- `npm run dev --prefix frontend`

## 5. Demo flow
1. Register an account with role `Donor` and add a food donation.
2. Register a second account with role `NGO`.
3. Sign in as the NGO, reserve an Available donation, then mark it Collected.
4. Refresh the page and confirm the updated status remains saved.

## Notes
- This is a hackathon prototype, not a production deployment.
- Authentication uses JWT and bcrypt password hashing, but production use needs additional security review, rate limiting, email verification, secure deployment configuration, and privacy review.
- For real food donations, do not list unsafe or expired food. The app blocks reservations after the expiry time; the donor is responsible for entering accurate dates.
