import mongoose from "mongoose";

const donationSchema = new mongoose.Schema(
  {
    foodName: { type: String, required: true, trim: true, maxlength: 120 },
    foodType: { type: String, enum: ["Vegetarian", "Non-Vegetarian", "Vegan", "Bakery", "Other"], required: true },
    quantity: { type: Number, required: true, min: 0.1 },
    quantityUnit: { type: String, enum: ["meals", "plates", "kg", "boxes"], required: true },
    donorName: { type: String, required: true, trim: true, maxlength: 100 },
    donorType: { type: String, enum: ["Restaurant", "Hostel", "Individual", "Caterer", "Other"], required: true },
    pickupLocation: { type: String, required: true, trim: true, maxlength: 200 },
    pickupTime: { type: Date, required: true },
    expiryTime: { type: Date, required: true },
    description: { type: String, trim: true, maxlength: 500, default: "" },
    status: { type: String, enum: ["Available", "Reserved", "Collected"], default: "Available" },
    donor: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    reservedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    reservedByName: { type: String, default: "" }
  },
  { timestamps: true }
);

donationSchema.index({ status: 1, pickupTime: 1 });
export default mongoose.model("Donation", donationSchema);
