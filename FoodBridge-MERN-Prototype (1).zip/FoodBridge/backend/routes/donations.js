import { Router } from "express";
import mongoose from "mongoose";
import Donation from "../models/Donation.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();
const allowedTypes = ["Vegetarian", "Non-Vegetarian", "Vegan", "Bakery", "Other"];
const allowedDonorTypes = ["Restaurant", "Hostel", "Individual", "Caterer", "Other"];
const allowedUnits = ["meals", "plates", "kg", "boxes"];

function validateDates(pickupTime, expiryTime) {
  const pickup = new Date(pickupTime);
  const expiry = new Date(expiryTime);
  if (Number.isNaN(pickup.getTime()) || Number.isNaN(expiry.getTime())) return "Enter valid pickup and expiry dates.";
  if (pickup > expiry) return "Pickup time must be before expiry time.";
  if (expiry <= new Date()) return "Expiry time must be in the future.";
  return null;
}
function validId(id) {
  return mongoose.isValidObjectId(id);
}

router.get("/", async (req, res, next) => {
  try {
    const { status, donorType, foodType, search } = req.query;
    const filter = {};
    if (["Available", "Reserved", "Collected"].includes(status)) filter.status = status;
    if (allowedDonorTypes.includes(donorType)) filter.donorType = donorType;
    if (allowedTypes.includes(foodType)) filter.foodType = foodType;
    if (search && String(search).trim()) {
      const safe = String(search).trim().slice(0, 80).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.$or = [{ foodName: { $regex: safe, $options: "i" } }, { pickupLocation: { $regex: safe, $options: "i" } }, { donorName: { $regex: safe, $options: "i" } }];
    }
    const donations = await Donation.find(filter).populate("donor", "name role").sort({ createdAt: -1 }).limit(200);
    res.json({ donations });
  } catch (err) { next(err); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid donation ID." });
    const donation = await Donation.findById(req.params.id).populate("donor", "name role");
    if (!donation) return res.status(404).json({ message: "Donation not found." });
    res.json({ donation });
  } catch (err) { next(err); }
});

router.post("/", requireAuth, requireRole("Donor"), async (req, res, next) => {
  try {
    const { foodName, foodType, quantity, quantityUnit, donorType, pickupLocation, pickupTime, expiryTime, description } = req.body;
    const q = Number(quantity);
    if (!foodName?.trim() || !allowedTypes.includes(foodType) || !Number.isFinite(q) || q <= 0 ||
        !allowedUnits.includes(quantityUnit) || !allowedDonorTypes.includes(donorType) || !pickupLocation?.trim() ||
        !pickupTime || !expiryTime) {
      return res.status(400).json({ message: "Complete all required fields with valid values." });
    }
    const dateError = validateDates(pickupTime, expiryTime);
    if (dateError) return res.status(400).json({ message: dateError });
    const donation = await Donation.create({
      foodName: foodName.trim(), foodType, quantity: q, quantityUnit,
      donorName: req.user.name, donorType, pickupLocation: pickupLocation.trim(),
      pickupTime: new Date(pickupTime), expiryTime: new Date(expiryTime),
      description: String(description || "").trim(), donor: req.user._id
    });
    res.status(201).json({ donation });
  } catch (err) { next(err); }
});

router.patch("/:id/reserve", requireAuth, requireRole("NGO"), async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid donation ID." });
    const donation = await Donation.findOneAndUpdate(
      { _id: req.params.id, status: "Available", expiryTime: { $gt: new Date() } },
      { $set: { status: "Reserved", reservedBy: req.user._id, reservedByName: req.user.name } },
      { new: true, runValidators: true }
    );
    if (!donation) return res.status(409).json({ message: "This donation is no longer available or has expired." });
    res.json({ donation, message: "Donation reserved successfully." });
  } catch (err) { next(err); }
});

router.patch("/:id/collect", requireAuth, requireRole("NGO"), async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid donation ID." });
    const donation = await Donation.findOneAndUpdate(
      { _id: req.params.id, status: "Reserved", reservedBy: req.user._id },
      { $set: { status: "Collected" } },
      { new: true, runValidators: true }
    );
    if (!donation) return res.status(409).json({ message: "Only the NGO that reserved this donation can mark it collected." });
    res.json({ donation, message: "Donation marked as collected." });
  } catch (err) { next(err); }
});

router.patch("/:id", requireAuth, requireRole("Donor"), async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid donation ID." });
    const existing = await Donation.findOne({ _id: req.params.id, donor: req.user._id });
    if (!existing) return res.status(404).json({ message: "Donation not found for your account." });
    if (existing.status !== "Available") return res.status(409).json({ message: "Only Available donations can be edited." });
    const fields = ["foodName", "foodType", "quantity", "quantityUnit", "donorType", "pickupLocation", "pickupTime", "expiryTime", "description"];
    const updates = {};
    for (const key of fields) if (req.body[key] !== undefined) updates[key] = req.body[key];
    const merged = { ...existing.toObject(), ...updates };
    if (updates.quantity !== undefined) updates.quantity = Number(updates.quantity);
    if (updates.foodType !== undefined && !allowedTypes.includes(updates.foodType)) return res.status(400).json({ message: "Invalid food type." });
    if (updates.quantityUnit !== undefined && !allowedUnits.includes(updates.quantityUnit)) return res.status(400).json({ message: "Invalid quantity unit." });
    if (updates.donorType !== undefined && !allowedDonorTypes.includes(updates.donorType)) return res.status(400).json({ message: "Invalid donor type." });
    if (updates.quantity !== undefined && (!Number.isFinite(updates.quantity) || updates.quantity <= 0)) return res.status(400).json({ message: "Quantity must be greater than zero." });
    if (updates.pickupTime || updates.expiryTime) {
      const dateError = validateDates(updates.pickupTime || existing.pickupTime, updates.expiryTime || existing.expiryTime);
      if (dateError) return res.status(400).json({ message: dateError });
    }
    if (updates.pickupTime) updates.pickupTime = new Date(updates.pickupTime);
    if (updates.expiryTime) updates.expiryTime = new Date(updates.expiryTime);
    const donation = await Donation.findByIdAndUpdate(req.params.id, { $set: updates }, { new: true, runValidators: true });
    res.json({ donation, message: "Donation updated." });
  } catch (err) { next(err); }
});

router.delete("/:id", requireAuth, requireRole("Donor"), async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid donation ID." });
    const donation = await Donation.findOneAndDelete({ _id: req.params.id, donor: req.user._id, status: "Available" });
    if (!donation) return res.status(404).json({ message: "Available donation not found for your account." });
    res.json({ message: "Donation deleted." });
  } catch (err) { next(err); }
});

export default router;
