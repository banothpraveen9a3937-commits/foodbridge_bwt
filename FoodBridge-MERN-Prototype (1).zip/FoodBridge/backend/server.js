import "dotenv/config";
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import authRoutes from "./routes/auth.js";
import donationRoutes from "./routes/donations.js";

const app = express();
const PORT = process.env.PORT || 5000;

if (!process.env.MONGO_URI || !process.env.JWT_SECRET) {
  console.error("Missing MONGO_URI or JWT_SECRET. Configure backend/.env first.");
  process.exit(1);
}

app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true, message: "FoodBridge API is running." }));
app.use("/api/auth", authRoutes);
app.use("/api/donations", donationRoutes);

app.use((req, res) => res.status(404).json({ message: "API route not found." }));
app.use((err, _req, res, _next) => {
  console.error(err.message);
  if (err.code === 11000) return res.status(409).json({ message: "An account with this email already exists." });
  if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
  res.status(500).json({ message: "Server error. Check the backend terminal for details." });
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected.");
    app.listen(PORT, () => console.log(`FoodBridge API listening on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  });
