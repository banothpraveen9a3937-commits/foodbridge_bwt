import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "./api";
import {
  ArrowRight, BadgeCheck, Check, ChefHat, Clock3, HandHeart, Heart,
  Leaf, LogOut, MapPin, PackageCheck, Plus, Search, ShieldCheck,
  Soup, Sparkles, Truck, Users, UtensilsCrossed, X
} from "lucide-react";

const emptyForm = {
  foodName: "", foodType: "Vegetarian", quantity: "20", quantityUnit: "meals",
  donorType: "Restaurant", pickupLocation: "", pickupTime: "", expiryTime: "", description: ""
};

function formatDate(value) {
  if (!value) return "Not set";
  return new Date(value).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

function AuthScreen({ onAuth }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "Donor" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const update = (key, value) => setForm((old) => ({ ...old, [key]: value }));

  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const path = mode === "login" ? "/auth/login" : "/auth/register";
      const data = await api(path, { method: "POST", body: JSON.stringify(form) });
      onAuth(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-page">
      <div className="auth-glow glow-one" /><div className="auth-glow glow-two" />
      <header className="auth-top"><div className="brand brand-light"><span className="brand-mark"><Leaf size={22} /></span><span>foodbridge<span className="brand-dot">.</span></span></div><span className="top-note"><ShieldCheck size={15} /> Community-powered giving</span></header>
      <section className="auth-layout">
        <div className="auth-story">
          <div className="eyebrow light-eyebrow"><Sparkles size={14} /> GOOD FOOD. GREATER GOOD.</div>
          <h1>Share more.<br /><em>Waste less.</em></h1>
          <p className="story-copy">A little extra food can make a meaningful difference. Connect surplus meals with the people and communities who need them.</p>
          <div className="story-stats">
            <div><span className="stat-icon"><HandHeart size={19} /></span><strong>Give with care</strong><small>List surplus food in minutes</small></div>
            <div><span className="stat-icon"><Truck size={19} /></span><strong>Collect with ease</strong><small>Coordinate pickup simply</small></div>
          </div>
          <div className="quote-card"><span className="quote-mark">“</span><p>Food is too good to waste, and kindness is too good not to share.</p><span className="quote-line" /></div>
        </div>
        <div className="auth-card">
          <div className="auth-card-heading"><span className="mini-icon"><Heart size={20} /></span><div><h2>{mode === "login" ? "Welcome back" : "Join FoodBridge"}</h2><p>{mode === "login" ? "Sign in to continue making a difference." : "Create your account to get started."}</p></div></div>
          <div className="auth-tabs"><button className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); setError(""); }}>Sign in</button><button className={mode === "register" ? "active" : ""} onClick={() => { setMode("register"); setError(""); }}>Create account</button></div>
          <form onSubmit={submit} className="auth-form">
            {mode === "register" && <label>Full name<input value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="e.g. Asha Kumar" required autoComplete="name" /></label>}
            <label>Email address<input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="you@example.com" required autoComplete="email" /></label>
            <label>Password<input type="password" minLength={8} value={form.password} onChange={(e) => update("password", e.target.value)} placeholder="At least 8 characters" required autoComplete={mode === "login" ? "current-password" : "new-password"} /></label>
            {mode === "register" && <label>I am joining as<select value={form.role} onChange={(e) => update("role", e.target.value)}><option value="Donor">Food donor — restaurant, hostel, individual</option><option value="NGO">NGO — reserve and collect food</option></select></label>}
            {error && <div className="error-banner"><X size={16} />{error}</div>}
            <button className="primary-btn full-btn" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in to FoodBridge" : "Create my account"} <ArrowRight size={17} /></button>
          </form>
          <p className="auth-terms"><ShieldCheck size={14} /> Your account helps coordinate donations responsibly.</p>
        </div>
      </section>
      <footer className="auth-footer">Made for communities, powered by compassion <span>•</span> FoodBridge prototype</footer>
    </main>
  );
}

function DonationModal({ onClose, onCreate }) {
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const update = (key, value) => setForm((old) => ({ ...old, [key]: value }));
  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      await onCreate({ ...form, quantity: Number(form.quantity), pickupTime: new Date(form.pickupTime).toISOString(), expiryTime: new Date(form.expiryTime).toISOString() });
      onClose();
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><section className="modal">
    <div className="modal-head"><div><span className="eyebrow">MAKE A DIFFERENCE</span><h2>Share a food donation</h2><p>Tell the community what is available for pickup.</p></div><button className="icon-btn" onClick={onClose} aria-label="Close"><X /></button></div>
    <form onSubmit={submit} className="donation-form">
      <label>Food name<input value={form.foodName} onChange={(e) => update("foodName", e.target.value)} placeholder="e.g. Fresh vegetable rice" required /></label>
      <div className="form-grid"><label>Food type<select value={form.foodType} onChange={(e) => update("foodType", e.target.value)}>{["Vegetarian","Non-Vegetarian","Vegan","Bakery","Other"].map(x => <option key={x}>{x}</option>)}</select></label><label>Donor type<select value={form.donorType} onChange={(e) => update("donorType", e.target.value)}>{["Restaurant","Hostel","Individual","Caterer","Other"].map(x => <option key={x}>{x}</option>)}</select></label></div>
      <div className="form-grid"><label>Quantity<input type="number" min="0.1" step="0.1" value={form.quantity} onChange={(e) => update("quantity", e.target.value)} required /></label><label>Unit<select value={form.quantityUnit} onChange={(e) => update("quantityUnit", e.target.value)}>{["meals","plates","kg","boxes"].map(x => <option key={x}>{x}</option>)}</select></label></div>
      <label>Pickup location<input value={form.pickupLocation} onChange={(e) => update("pickupLocation", e.target.value)} placeholder="Building, street or landmark" required /></label>
      <div className="form-grid"><label>Pickup time<input type="datetime-local" value={form.pickupTime} onChange={(e) => update("pickupTime", e.target.value)} required /></label><label>Expiry time<input type="datetime-local" value={form.expiryTime} onChange={(e) => update("expiryTime", e.target.value)} required /></label></div>
      <label>Description <span className="optional">(optional)</span><textarea rows="3" value={form.description} onChange={(e) => update("description", e.target.value)} placeholder="Storage, packaging or pickup notes…" /></label>
      {error && <div className="error-banner"><X size={16} />{error}</div>}
      <button className="primary-btn full-btn" disabled={busy}>{busy ? "Publishing…" : "Publish donation"} <ArrowRight size={17} /></button>
    </form>
  </section></div>;
}

function DonationCard({ donation, user, onReserve, onCollect, onDelete }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const isOwner = donation.donor?._id === user.id || donation.donor === user.id;
  const isReservedByMe = donation.reservedBy === user.id;
  async function action(fn) {
    setBusy(true); setError("");
    try { await fn(donation._id); } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  const statusClass = donation.status.toLowerCase();
  return <article className="donation-card">
    <div className={`food-art art-${donation.foodType.toLowerCase().replace(/[^a-z]/g,"")}`}><div className="food-art-orb"><Soup size={36} /></div><span className="food-type-chip">{donation.foodType}</span><span className={`status-pill ${statusClass}`}>{donation.status}</span></div>
    <div className="donation-content">
      <div className="card-title-row"><div><h3>{donation.foodName}</h3><p className="donor-line"><ChefHat size={14} /> {donation.donorName} <span>·</span> {donation.donorType}</p></div></div>
      <div className="quantity-line"><span className="quantity-number">{donation.quantity}</span><span>{donation.quantityUnit} available</span></div>
      <div className="detail-line"><MapPin size={15} /><span>{donation.pickupLocation}</span></div>
      <div className="detail-line"><Clock3 size={15} /><span>Pickup: {formatDate(donation.pickupTime)}</span></div>
      <div className="expiry-line">Use by {formatDate(donation.expiryTime)}</div>
      {donation.description && <p className="description">{donation.description}</p>}
      {error && <div className="inline-error">{error}</div>}
      <div className="card-actions">
        {user.role === "NGO" && donation.status === "Available" && <button className="primary-btn card-btn" disabled={busy} onClick={() => action(onReserve)}>{busy ? "Reserving…" : "Reserve donation"} <ArrowRight size={15} /></button>}
        {user.role === "NGO" && donation.status === "Reserved" && isReservedByMe && <button className="collect-btn card-btn" disabled={busy} onClick={() => action(onCollect)}>{busy ? "Updating…" : <><PackageCheck size={16} /> Mark collected</>}</button>}
        {user.role === "Donor" && isOwner && donation.status === "Available" && <button className="delete-btn" disabled={busy} onClick={() => { if (window.confirm("Delete this available donation?")) action(onDelete); }}><X size={15} /> Delete listing</button>}
        {user.role === "NGO" && donation.status === "Reserved" && !isReservedByMe && <span className="reserved-note"><ShieldCheck size={14} /> Reserved by another NGO</span>}
        {donation.status === "Collected" && <span className="collected-note"><BadgeCheck size={15} /> Collection completed</span>}
      </div>
    </div>
  </article>;
}

function Dashboard({ user, token, onLogout }) {
  const [donations, setDonations] = useState([]);
  const [filters, setFilters] = useState({ search: "", status: "", foodType: "" });
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [refresh, setRefresh] = useState(0);

  const loadDonations = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const params = new URLSearchParams();
      if (filters.search.trim()) params.set("search", filters.search.trim());
      if (filters.status) params.set("status", filters.status);
      if (filters.foodType) params.set("foodType", filters.foodType);
      const data = await api(`/donations?${params.toString()}`);
      setDonations(data.donations || []);
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  }, [filters, refresh]);

  useEffect(() => { loadDonations(); }, [loadDonations]);

  const counts = useMemo(() => ({
    available: donations.filter(d => d.status === "Available").length,
    reserved: donations.filter(d => d.status === "Reserved").length,
    collected: donations.filter(d => d.status === "Collected").length,
    meals: donations.filter(d => d.status !== "Collected").reduce((sum, d) => sum + Number(d.quantity || 0), 0)
  }), [donations]);

  async function createDonation(payload) {
    await api("/donations", { method: "POST", body: JSON.stringify(payload) }, token);
    setToast("Your donation is now listed. Thank you for sharing!");
    setRefresh(n => n + 1);
  }
  async function reserveDonation(id) {
    await api(`/donations/${id}/reserve`, { method: "PATCH", body: JSON.stringify({}) }, token);
    setToast("Donation reserved. Coordinate pickup with the donor.");
    setRefresh(n => n + 1);
  }
  async function collectDonation(id) {
    await api(`/donations/${id}/collect`, { method: "PATCH", body: JSON.stringify({}) }, token);
    setToast("Collection marked complete. Thank you!");
    setRefresh(n => n + 1);
  }
  async function deleteDonation(id) {
    await api(`/donations/${id}`, { method: "DELETE" }, token);
    setToast("Donation listing deleted.");
    setRefresh(n => n + 1);
  }

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 3600);
    return () => clearTimeout(timer);
  }, [toast]);

  return <main className="dashboard-page">
    <header className="app-header"><a href="#" className="brand"><span className="brand-mark"><Leaf size={21} /></span><span>foodbridge<span className="brand-dot">.</span></span></a><nav className="header-nav"><a href="#donations">Discover food</a><a href="#how-it-works">How it works</a></nav><div className="header-user"><span className="avatar">{user.name.slice(0,1).toUpperCase()}</span><div className="user-label"><strong>{user.name}</strong><small>{user.role} account</small></div><button className="logout-btn" onClick={onLogout}><LogOut size={16} /><span>Sign out</span></button></div></header>
    <section className="hero">
      <div className="hero-content"><div className="eyebrow"><span className="eyebrow-dot" /> GOOD FOOD DESERVES A GOOD HOME</div><h1>Turn extra food into<br /><em>extra good.</em></h1><p>Small acts of sharing can make a big difference. Find surplus food, connect with your community, and help good meals reach good people.</p><div className="hero-actions">{user.role === "Donor" ? <button className="hero-cta" onClick={() => setShowModal(true)}><Plus size={18} /> Share surplus food</button> : <a className="hero-cta" href="#donations"><Search size={18} /> Find food donations</a>}<div className="hero-proof"><span className="proof-avatars"><i>F</i><i>N</i><i>♥</i></span><span>Better together, every day</span></div></div></div>
      <div className="hero-visual"><div className="visual-blob blob-back" /><div className="visual-blob blob-front" /><div className="visual-circle"><UtensilsCrossed size={88} strokeWidth={1.15} /></div><div className="floating-card floating-top"><span className="floating-icon"><Leaf size={18} /></span><div><strong>Goodness shared</strong><small>One meal at a time</small></div><BadgeCheck size={18} className="floating-check" /></div><div className="floating-card floating-bottom"><span className="floating-icon warm"><Heart size={18} /></span><div><strong>Community first</strong><small>Give food a second chance</small></div></div><span className="sparkle sparkle-a">✳</span><span className="sparkle sparkle-b">✦</span></div>
    </section>
    <section className="stats-grid">
      <div className="stat-card"><span className="stat-card-icon green"><Soup size={19} /></span><div><small>Available now</small><strong>{counts.available}</strong><span>donations to discover</span></div></div>
      <div className="stat-card"><span className="stat-card-icon amber"><Clock3 size={19} /></span><div><small>Reserved</small><strong>{counts.reserved}</strong><span>awaiting collection</span></div></div>
      <div className="stat-card"><span className="stat-card-icon purple"><PackageCheck size={19} /></span><div><small>Collected</small><strong>{counts.collected}</strong><span>completed handoffs</span></div></div>
      <div className="stat-card"><span className="stat-card-icon coral"><HandHeart size={19} /></span><div><small>Food in circulation</small><strong>{counts.meals}</strong><span>listed units, excluding collected</span></div></div>
    </section>
    <section className="donations-section" id="donations">
      <div className="section-heading"><div><div className="eyebrow">THE COMMUNITY TABLE</div><h2>{user.role === "NGO" ? "Discover food donations" : "Your community's donations"}</h2><p>{user.role === "NGO" ? "Find available food and reserve a pickup for your organization." : "Every listing is a chance to turn surplus into support."}</p></div>{user.role === "Donor" && <button className="secondary-cta" onClick={() => setShowModal(true)}><Plus size={17} /> Add donation</button>}</div>
      <div className="filter-bar"><div className="search-box"><Search size={18} /><input placeholder="Search food or pickup location…" value={filters.search} onChange={e => setFilters(f => ({ ...f, search: e.target.value }))} /></div><select aria-label="Filter by status" value={filters.status} onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}><option value="">All statuses</option><option>Available</option><option>Reserved</option><option>Collected</option></select><select aria-label="Filter by food type" value={filters.foodType} onChange={e => setFilters(f => ({ ...f, foodType: e.target.value }))}><option value="">All food types</option>{["Vegetarian","Non-Vegetarian","Vegan","Bakery","Other"].map(x => <option key={x}>{x}</option>)}</select></div>
      {error && <div className="error-banner page-error"><X size={16} />{error} <button onClick={() => setRefresh(n => n + 1)}>Retry</button></div>}
      {loading ? <div className="loading-state"><span className="spinner" /> Loading community donations…</div> : donations.length === 0 ? <div className="empty-state"><span className="empty-icon"><Soup size={28} /></span><h3>No donations found just yet</h3><p>{user.role === "Donor" ? "Be the first to share a surplus meal with your community." : "Try changing your filters or check back soon."}</p>{user.role === "Donor" && <button className="primary-btn" onClick={() => setShowModal(true)}><Plus size={16} /> Add first donation</button>}</div> : <div className="donation-grid">{donations.map(d => <DonationCard key={d._id} donation={d} user={user} onReserve={reserveDonation} onCollect={collectDonation} onDelete={deleteDonation} />)}</div>}
    </section>
    <section className="how-section" id="how-it-works"><div className="eyebrow">SIMPLE STEPS, REAL IMPACT</div><h2>Good things happen when we share.</h2><div className="how-grid"><div><span className="how-icon"><ChefHat /></span><span className="step-number">01 / DONORS</span><h3>List what you can share</h3><p>Restaurants, hostels and individuals list surplus food with pickup details.</p></div><div><span className="how-icon"><Users /></span><span className="step-number">02 / NGOS</span><h3>Reserve a donation</h3><p>NGOs browse available food and reserve what they can collect in time.</p></div><div><span className="how-icon"><PackageCheck /></span><span className="step-number">03 / COMMUNITY</span><h3>Complete the handoff</h3><p>Mark the food collected and help good food find a useful destination.</p></div></div></section>
    <footer className="app-footer"><a href="#" className="brand"><span className="brand-mark"><Leaf size={19} /></span><span>foodbridge<span className="brand-dot">.</span></span></a><span>Share more. Waste less. Care together.</span><span className="footer-tag"><Heart size={14} /> Built for community impact</span></footer>
    {showModal && <DonationModal onClose={() => setShowModal(false)} onCreate={createDonation} />}
    {toast && <div className="toast"><span><Check size={17} /></span>{toast}</div>}
  </main>;
}

export default function App() {
  const [session, setSession] = useState(() => {
    try { return JSON.parse(localStorage.getItem("foodbridge-session") || "null"); } catch { return null; }
  });
  function handleAuth(data) {
    const next = { token: data.token, user: data.user };
    localStorage.setItem("foodbridge-session", JSON.stringify(next));
    setSession(next);
  }
  function logout() {
    localStorage.removeItem("foodbridge-session");
    setSession(null);
  }
  useEffect(() => {
    if (!session?.token) return;
    api("/auth/me", {}, session.token).then(data => {
      setSession(old => old ? { ...old, user: data.user } : old);
    }).catch(() => logout());
    // Token validation is performed once when a saved session is loaded.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (!session?.token || !session?.user) return <AuthScreen onAuth={handleAuth} />;
  return <Dashboard user={session.user} token={session.token} onLogout={logout} />;
}
